#pragma once
#include <vector>
#include <map>
#include <string>
#include <optional>
#include <fstream>
#include <iostream>

#include "../../accsys/include/ir/type.h"
#include "../../accsys/lib/ir/ir_writer.cpp"
#include "../ast/ast.h"

struct Param {
    bool isArray;
    std::string name;
    std::vector<std::optional<std::size_t>> dims;
};
struct IrReturnInfo {
    Value* value;
    std::vector<Value*> vecValue;
};

// Module
Module* module = new Module();

// Function
std::vector<Type *> args;
FunctionType *nunitty = FunctionType::get(Type::getUnitTy(), args);
FunctionType *nintegerty = FunctionType::get(Type::getIntegerTy(), args);

Function* InitFunc = Function::Create(nunitty, false, "Invalid", nullptr);
Function* cur_func = InitFunc;
std::map<std::string, Function*> RuntimeFunc;
std::vector<Param *> Params;

// BasicBlock
BasicBlock* InitBB = BasicBlock::Create(InitFunc); 
BasicBlock* cur_bb = InitBB;

// Instruction
Instruction* cur_inst;

// Value
std::map<std::string, std::vector<std::optional<std::size_t>>> arrayTable;
std::map<std::string, Value*> variableAlloc;
std::map<std::string, Value*> arrayAlloc;

void init_Runtime() {
    args.emplace_back(Type::getIntegerTy());
    FunctionType *unitty = FunctionType::get(Type::getUnitTy(), args);
    args.emplace_back(PointerType::get(Type::getIntegerTy()));
    FunctionType *putarrayty = FunctionType::get(Type::getUnitTy(), args);
    std::vector<Type *> getarrayArg;
    getarrayArg.emplace_back(Type::getIntegerTy());
    FunctionType *getarrayty = FunctionType::get(Type::getIntegerTy(), getarrayArg);

    Function* getch = Function::Create(nintegerty, false, "getch", nullptr);
    Function* getint = Function::Create(nintegerty, false, "getint", nullptr);
    Function* getarray = Function::Create(getarrayty, false, "getarray", nullptr);

    Function* putint = Function::Create(unitty, false, "putint", nullptr);
    Function* putch = Function::Create(unitty, false, "putch", nullptr);
    Function* putarray = Function::Create(putarrayty, false, "putarray", nullptr);  

    Function* starttime = Function::Create(nunitty, false, "starttime", nullptr);
    Function* stoptime = Function::Create(nunitty, false, "stoptime", nullptr);

    RuntimeFunc["getch"] = getch;
    RuntimeFunc["getint"] = getint;
    RuntimeFunc["getarray"] = getarray;
    RuntimeFunc["putint"] = putint;
    RuntimeFunc["putch"] = putch;
    RuntimeFunc["putarray"] = putarray;
    RuntimeFunc["starttime"] = starttime;
    RuntimeFunc["stoptime"] = stoptime;
}

int findParams(Node* node) {
    int result = 0;
    if (node->is_terminal()) {
        return 0;
    }
    auto temp_node = static_cast<NonTerminalNode*>(node);
    if (node->node_type == "FuncFParams") {
        int size = temp_node->child_list.size();
        for (int i = 0; i < size; i++) {
            result += findParams(temp_node->child_list[i]);
        }
    } else {
        if (temp_node->node_type == "IntegerFuncFParam") {
            auto param = new Param();
            param->isArray = false;
            param->name = static_cast<IdentLiteral*>(temp_node->child_list[1])->value;
            Params.emplace_back(param);
        } else if (temp_node->node_type == "BracketFuncFParam") { // array
            std::vector<std::optional<std::size_t>> dims;
            dims.emplace_back(std::nullopt);
            auto bracket_intlist = static_cast<NonTerminalNode*>(temp_node->child_list[2]);
            int size = bracket_intlist->child_list.size();
            for (int i = 0; i < size; i++) {
                int64_t tmp1 = static_cast<IntegerLiteral*>(bracket_intlist->child_list[i])->value;
                dims.emplace_back(static_cast<std::size_t>(tmp1));
            }
            auto param = new Param();
            param->isArray = true;
            param->dims = dims;
            param->name = static_cast<IdentLiteral*>(temp_node->child_list[1])->value;
            Params.emplace_back(param);
        } else {
            std::cout << "Error: findParams" << std::endl;
        }
        result = 1;
    }
    return result;
}

IrReturnInfo* construct_ir(Node* node, BasicBlock* tb, BasicBlock* fb) {

    auto ret = new IrReturnInfo();

    if (node == nullptr) {
        return nullptr;
    }
    
    if (node->node_type == "CompUnit") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        int size = temp_node->child_list.size();
        for (int i = 0; i < size; i++) {
            construct_ir(temp_node->child_list[i], tb, fb);
        }
        return nullptr;
    }
    else if (node->node_type == "VarDecl") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        int size = temp_node->child_list.size();
        for (int i = 1; i < size; i++) {
            construct_ir(temp_node->child_list[i], tb, fb);
        }
        return nullptr;
    }
    else if (node->node_type == "IntegerVarDef") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        if (cur_func->getName() == "Invalid") { // 全局变量
            std::string name = static_cast<IdentLiteral*>(static_cast<NonTerminalNode*>(node)->child_list[0])->value;
            GlobalVariable* global = GlobalVariable::Create(Type::getIntegerTy(), 1, false, name, module);
            global->setName(name);
            if (temp_node->child_list.size() == 2) { // 有初始化赋值
                variableAlloc[name] = global;
                cur_inst = StoreInst::Create(construct_ir(temp_node->child_list[1], tb, fb)->value, global, InitBB);
            } else {
                variableAlloc[name] = global;
                ret->value = global;
                return ret;
            }
        } else {
            std::string name = static_cast<IdentLiteral*>(static_cast<NonTerminalNode*>(node)->child_list[0])->value;
            auto declare = AllocaInst::Create(Type::getIntegerTy(), 1, cur_bb);
            cur_inst = declare;
            if (temp_node->child_list.size() == 2) { // 有初始化赋值
                variableAlloc[name] = cur_inst;
                cur_inst = StoreInst::Create(construct_ir(temp_node->child_list[1], tb, fb)->value, declare, cur_bb);
            } else {
                variableAlloc[name] = cur_inst;
                ret->value = cur_inst;
                return ret;
            }
        }
        return nullptr;
    }
    else if (node->node_type == "BracketVarDef") { // 不考虑数组初始化
        auto temp_node = static_cast<NonTerminalNode*>(node);
        std::string name = static_cast<IdentLiteral*>(static_cast<NonTerminalNode*>(node)->child_list[0])->value;
        std::vector<std::optional<std::size_t>> dims;
        auto bracket_intlist = static_cast<NonTerminalNode*>(temp_node->child_list[1]);
        int size = bracket_intlist->child_list.size();
        int nums = 1;
        for (int i = 0; i < size; i++) {
            int64_t tmp1 = static_cast<IntegerLiteral*>(bracket_intlist->child_list[i])->value;
            dims.emplace_back(static_cast<std::size_t>(tmp1));
            nums *= tmp1;
        }
        arrayTable[name] = dims;
        if (cur_func->getName() == "Invalid") { // 全局变量
            GlobalVariable* global = GlobalVariable::Create(Type::getIntegerTy(), nums, false, name, module);
            global->setName(name);
            arrayAlloc[name] = global;
            ret->value = global;
            return ret;
        } else {
            auto declare = AllocaInst::Create(Type::getIntegerTy(), nums, cur_bb);
            cur_inst = declare;
            arrayAlloc[name] = declare;
            ret->value = cur_inst;
            return ret;
        }
        return nullptr;
    }
    else if (node->node_type == "FuncDef") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        std::vector<Type *> params;
        std::string funcTy = temp_node->child_list[0]->node_type;
        std::string funcName = static_cast<IdentLiteral*>(temp_node->child_list[1])->value;
        
        if (temp_node->child_list.size() == 3) { // 没有参数
            auto functy = FunctionType::get(funcTy == "IdentType_VOID" ? Type::getUnitTy() : Type::getIntegerTy(), params);
            cur_func = Function::Create(functy, false, funcName, module);
            auto bb = cur_bb;
            cur_bb = BasicBlock::Create(cur_func, nullptr);
            cur_bb->setPrior(bb);
            construct_ir(temp_node->child_list[2], tb, fb);
        } else { // 有参数
            Params.clear();
            findParams(temp_node->child_list[2]);
            for (auto param : Params) {
                auto ptr = PointerType::get(Type::getIntegerTy());
                if (param->isArray) params.emplace_back(ptr);
                else params.emplace_back(Type::getIntegerTy());
            }
            auto functy = FunctionType::get(funcTy == "IdentType_VOID" ? Type::getUnitTy() : Type::getIntegerTy(), params);
            cur_func = Function::Create(functy, false, funcName, module);
            auto bb = cur_bb;
            cur_bb = BasicBlock::Create(cur_func, nullptr);
            cur_bb->setPrior(bb);

            auto start = cur_func->arg_begin();
            for (auto &param : Params) {
                if (param->isArray) {
                    auto ptr = PointerType::get(Type::getIntegerTy());
                    cur_inst = AllocaInst::Create(ptr, 1, cur_bb);
                    StoreInst::Create(start, cur_inst, cur_bb);
                    arrayAlloc[param->name] = start;
                    arrayTable[param->name] = param->dims;
                } else {
                    cur_inst = AllocaInst::Create(Type::getIntegerTy(), 1, cur_bb);
                    StoreInst::Create(start, cur_inst, cur_bb);
                    variableAlloc[param->name] = cur_inst;
                }
                start->setName(param->name);
                start++;
            }
            construct_ir(temp_node->child_list[3], tb, fb);
        }
        // 继续判断全局变量
        cur_func = InitFunc;
        cur_bb = InitBB;
        return nullptr;
    }
    else if (node->node_type == "Block") {
        // enter a new domain
        auto temp_node = static_cast<NonTerminalNode*>(node);
        int size = temp_node->child_list.size();
        for (int i = 0; i < size; i++) {
            construct_ir(temp_node->child_list[i], tb, fb);
        }
        // end the domain
        return nullptr;
    }
    else if (node->node_type == "AssignStmt") {
        // Stmt : LVal ASN Exp SEMI
        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto lval = construct_ir(temp_node->child_list[0], tb, fb);
        auto exp = construct_ir(temp_node->child_list[1], tb, fb);
        StoreInst::Create(exp->value, lval->value, cur_bb);
        return nullptr;
    }
    else if (node->node_type == "IfElseStmt") {
        // Stmt : IF LP Exp RP Stmt ELSE Stmt
        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto ret_bb = cur_bb;
        cur_bb = BasicBlock::Create(cur_func);
        JumpInst::Create(cur_bb, ret_bb);
        ret_bb = cur_bb;
        auto temp = BasicBlock::Create(cur_func);
        cur_bb = BasicBlock::Create(cur_func, temp);
        cur_bb->setPrior(ret_bb);
        tb = cur_bb;
        construct_ir(temp_node->child_list[1], tb, fb); // 第一个stmt
        if (!cur_bb->getTerminator() || !Instruction::isTerminator(cur_bb->getTerminator()->getOpcode())) {
            JumpInst::Create(temp, cur_bb);
        }
        if (temp_node->child_list.size() > 2) {
            cur_bb = BasicBlock::Create(cur_func, temp);
            cur_bb->setPrior(ret_bb);
            fb = cur_bb;
            construct_ir(temp_node->child_list[2], tb, fb); // 第二个stmt
            if (!cur_bb->getTerminator()) {
                JumpInst::Create(temp, cur_bb);
            }
            cur_bb = ret_bb;
            auto condition = construct_ir(temp_node->child_list[0], tb, fb); // 条件判断式
            if (condition->value) BranchInst::Create(tb, fb, condition->value, ret_bb);
        } else {
            cur_bb = ret_bb;
            auto conditon = construct_ir(temp_node->child_list[0], tb, temp); // 条件判断式
            if (conditon->value) BranchInst::Create(tb, temp, conditon->value, ret_bb);
        }
        cur_bb = temp;
        return nullptr;
    }
    else if (node->node_type == "WhileStmt") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto ret_bb = cur_bb;
        cur_bb = BasicBlock::Create(cur_func);
        JumpInst::Create(cur_bb, ret_bb);
        ret_bb = cur_bb;
        tb = BasicBlock::Create(cur_func);
        fb = BasicBlock::Create(cur_func);
        cur_bb = tb;
        construct_ir(temp_node->child_list[1], tb, fb); // body
        JumpInst::Create(ret_bb, cur_bb);
        cur_bb = ret_bb;
        auto condition = construct_ir(temp_node->child_list[0], tb, fb); // condition
        if (condition->value) BranchInst::Create(tb, fb, condition->value, ret_bb);
        cur_bb = fb;
        return nullptr;
    }
    else if (node->node_type == "BreakStmt") { // break
        JumpInst::Create(cur_bb->getPrior(), cur_bb);
        cur_bb = cur_bb->getPrior()->getPrior();
        return nullptr;
    }
    else if (node->node_type == "ContinueStmt") { // continue
        JumpInst::Create(cur_bb->getPrior(), cur_bb);
        cur_bb = cur_bb->getPrior();
        return nullptr;
    }
    else if (node->node_type == "ReturnStmt") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        cur_func->setReturnType(Type::getIntegerTy());
        if (temp_node->child_list.size() == 1) {
            RetInst::Create(ConstantInt::Create(0), cur_bb);
        } else {
            auto res = construct_ir(temp_node->child_list[1], tb, fb);
            RetInst::Create(res->value, cur_bb);
        }
    }
    else if (node->node_type == "LVal") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        std::string name = static_cast<IdentLiteral*>(temp_node->child_list[0])->value;
        if (temp_node->child_list.size() == 1) {
            if (arrayTable.find(name) != arrayTable.end()) { // 是数组名
                std::vector<Value *> dims;
                while (dims.size() < arrayTable[name].size()) {
                    dims.emplace_back(ConstantInt::Create(0));
                }
                cur_inst = OffsetInst::Create(Type::getIntegerTy(), arrayAlloc[name], dims, arrayTable[name], cur_bb);
                ret->value = cur_inst;
            } else {
                cur_inst = LoadInst::Create(variableAlloc[name], cur_bb);
                ret->value = variableAlloc[name];
            }
        } else if (temp_node->child_list.size() == 2){ // array
            bool flag = false;
            auto dims = construct_ir(temp_node->child_list[1], tb, fb);
            if (dims->vecValue.size() < arrayTable[name].size()) {
                flag = true;
                while (dims->vecValue.size() < arrayTable[name].size()) 
                    dims->vecValue.emplace_back(ConstantInt::Create(0));
            }
            cur_inst = OffsetInst::Create(Type::getIntegerTy(), arrayAlloc[name], dims->vecValue, arrayTable[name], cur_bb);
            ret->value = cur_inst;
            if (!flag) {
                cur_inst = LoadInst::Create(cur_inst, cur_bb);
            }
        }
        return ret;
    }
    else if (node->node_type == "BracketExpList") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        int size = temp_node->child_list.size();
        std::vector<Value *> vecValue;
        for (int i = 0; i < size; i++) {
            vecValue.emplace_back(construct_ir(temp_node->child_list[i], tb, fb)->value);
        }
        ret->vecValue = vecValue;
        return ret;
    }
    else if (node->node_type == "AddExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Add, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "SubExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Sub, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "MulExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Mul, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "DivExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Div, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "ModExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Mod, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "LOrExp") {
        // 短路，下面的逻辑表达式同理
        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto pre = cur_bb;
        auto next = BasicBlock::Create(cur_func, tb);
        auto shortcut = construct_ir(temp_node->child_list[0], tb, next)->value;
        if (shortcut) BranchInst::Create(tb, next, shortcut, pre);
        cur_bb = next;
        auto ifpass = construct_ir(temp_node->child_list[1], tb, fb)->value;
        if (ifpass) BranchInst::Create(tb, fb, ifpass, cur_bb);
        ret->value = nullptr;
        return ret;
    }
    else if (node->node_type == "LAndExp") {
        // 短路，下面的逻辑表达式同理
        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto pre = cur_bb;
        auto next = BasicBlock::Create(cur_func, tb);
        auto shortcut = construct_ir(temp_node->child_list[0], next, fb)->value;
        if (shortcut) BranchInst::Create(next, fb, shortcut, pre);
        cur_bb = next;
        auto ifpass = construct_ir(temp_node->child_list[1], tb, fb)->value;
        if (ifpass) BranchInst::Create(tb, fb, ifpass, cur_bb);
        ret->value = nullptr;
        return ret;
    }
    else if (node->node_type == "EqExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Eq, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "NEqExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Ne, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "LTExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Lt, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "GTExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Gt, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "LTEExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Le, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "GTEExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Ge, construct_ir(temp_node->child_list[0], tb, fb)->value, construct_ir(temp_node->child_list[1], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "AddUnaryExp") {
        return construct_ir(static_cast<NonTerminalNode*>(node)->child_list[0], tb, fb);
    }
    else if (node->node_type == "SubUnaryExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Sub, ConstantInt::Create(0), construct_ir(temp_node->child_list[0], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "NotUnaryExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        ret->value = BinaryInst::Create(Instruction::BinaryOps::Xor, ConstantInt::Create(true), construct_ir(temp_node->child_list[0], tb, fb)->value, Type::getIntegerTy(), cur_bb);
        return ret;
    }
    else if (node->node_type == "FuncCall") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        std::string name = static_cast<IdentLiteral*>(temp_node->child_list[0])->value;
        if (RuntimeFunc.find(name) == RuntimeFunc.end()) {
            if (temp_node->child_list.size() == 1) {
                std::vector<Value *> args;
                ret->value = CallInst::Create(module->getFunction(name), args, cur_bb);
            } else {
                ret->value = CallInst::Create(module->getFunction(name), construct_ir(temp_node->child_list[1], tb, fb)->vecValue, cur_bb);
            }
        } else {
            if (temp_node->child_list.size() == 1) {
                std::vector<Value *> args;
                ret->value = CallInst::Create(RuntimeFunc[name], args, cur_bb);
            } else {
                ret->value = CallInst::Create(RuntimeFunc[name], construct_ir(temp_node->child_list[1], tb, fb)->vecValue, cur_bb);
            }
        }
        return ret;
    }
    else if (node->node_type == "FuncRParams") {
        std::vector<Value *> real_params;
        auto temp_node = static_cast<NonTerminalNode*>(node);
        int size = temp_node->child_list.size();
        for (int i = 0; i < size; i++) {
            real_params.emplace_back(construct_ir(temp_node->child_list[i], tb, fb)->value);
        }
        ret->vecValue = real_params;
        return ret;
    }
    else if (node->node_type == "IntegerLiteral") {
        auto temp_node = static_cast<IntegerLiteral*>(node);
        ret->value = ConstantInt::Create(static_cast<uint32_t>(temp_node->value));
        return ret;
    }
    else if (node->node_type == "PrimaryExp") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        if (temp_node->child_list.size() == 1) {
            if (temp_node->child_list[0]->node_type == "LVal") {
                construct_ir(temp_node->child_list[0], tb, fb);
                ret->value = cur_inst;
                return ret;
            } else {
                return construct_ir(temp_node->child_list[0], tb, fb);
            }
        } else {
            std::cout << "Error: PrimaryExp" << std::endl;
        }
    }
    else {
        std::cout << "Error: construct_ir" << std::endl;
        return nullptr;
    }
    return nullptr;
 }

/*--------------------------------------------------------------------------------------------*/
void run_ir_constructor(Node* node, std::ofstream &fout) {
    init_Runtime();
    construct_ir(node, nullptr, nullptr);
    auto first_bb = module->getFunction("main")->begin();
    auto first_inst = first_bb->begin();
    int size = InitBB->size();
    for (auto iter = InitBB->begin(); size > 0; size--) {
        iter->insertBefore(*first_bb, first_inst);
    }
    module->print(fout, true);
    // delete module;
}
/*--------------------------------------------------------------------------------------------*/