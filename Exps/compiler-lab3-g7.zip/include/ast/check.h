#pragma once
#include <vector>
#include <map>
#include <string>
#include "ast.h"
#include <iostream>

// INT or VOID or ARRAY···
using VType = std::string;

struct IdentNode {
    VType type;
    int dim = 0;
    // if array, dim > 0 
    std::vector<int> size{};
};

struct FuncNode {
    VType type;
    std::vector<IdentNode> FuncParams{};
};

std::vector<std::map<std::string, IdentNode>> IdentMap{};
std::map<std::string, FuncNode> FuncMap{};

std::string now_funcType = "ERROR";
bool if_inloop = false;
bool if_infunc = false;
bool already_copy = false;

bool check_tree(Node* node);
VType check_type(Node* node);

void push_domain() {
    std::map<std::string, IdentNode> IdMap{};
    IdentMap.push_back(IdMap);
}

void pop_domain() {
    if (!IdentMap.empty()) IdentMap.pop_back();
}

void copy_domain() {
    int top = IdentMap.size() - 1;
    IdentMap[top] = IdentMap[top - 1];
    return;
}

void init_domain() {
    FuncNode* getint = new FuncNode();
    getint->type = "INT";
    FuncMap["getint"] = *getint;

    FuncNode* getch = new FuncNode();
    getch->type = "INT";
    FuncMap["getch"] = *getch;

    FuncNode* getarray = new FuncNode();
    getarray->type = "INT";
    IdentNode* param_of_array = new IdentNode();
    param_of_array->type = "ARRAY";
    param_of_array->dim = 1;
    getarray->FuncParams.push_back(*param_of_array);
    FuncMap["getarray"] = *getarray;

    FuncNode* putint = new FuncNode();
    putint->type = "VOID";
    IdentNode* param_of_putint = new IdentNode();
    param_of_putint->type = "INT";
    param_of_putint->dim = 0;
    putint->FuncParams.push_back(*param_of_putint);
    FuncMap["putint"] = *putint;

    FuncNode* putch = new FuncNode();
    putch->type = "VOID";
    IdentNode* param_of_putch = new IdentNode();
    param_of_putch->type = "INT";
    param_of_putch->dim = 0;
    putch->FuncParams.push_back(*param_of_putch);
    FuncMap["putch"] = *putch;

    FuncNode* putarray = new FuncNode();
    putarray->type = "VOID";
    IdentNode* param_of_putarray1 = new IdentNode();
    param_of_putarray1->type = "INT";
    param_of_putarray1->dim = 0;
    putarray->FuncParams.push_back(*param_of_putarray1);
    IdentNode* param_of_putarray2 = new IdentNode();
    param_of_putarray2->type = "ARRAY";
    param_of_putarray2->dim = 1;
    putarray->FuncParams.push_back(*param_of_putarray2);
    FuncMap["putarray"] = *putarray;

    FuncNode* starttime = new FuncNode();
    getint->type = "VOID";
    FuncMap["starttime"] = *starttime;

    FuncNode* stoptime = new FuncNode();
    getint->type = "VOID";
    FuncMap["stoptime"] = *stoptime;
}

/*-----------------------------------------------------------------------------*/

IdentNode* find_id(std::string ident) {
    int n = IdentMap.size();
    for (int i = n - 1; i >= 0; i--) {
        auto temp = IdentMap[i].find(ident);
        if (temp != IdentMap[i].end()) {
            return &(IdentMap[i][ident]);
        }
    }
    return nullptr;
}

IdentNode* find_id_inScope(std::string ident) {
    int i = IdentMap.size() - 1;
    auto temp = IdentMap[i].find(ident);
    if (temp != IdentMap[i].end()) {
        return &(IdentMap[i][ident]);
    }
    return nullptr;
}

FuncNode* find_func(std::string func_name) {
    auto temp = FuncMap.find(func_name);
    if (temp != FuncMap.end()) {
        return &(FuncMap[func_name]);
    }
    return nullptr;
}

/*----------------------------------------------------------------------------*/

bool ifBanary(Node* node) {
    if (node->node_type == "AddExp" || \
        node->node_type == "SubExp" || \
        node->node_type == "MulExp" || \
        node->node_type == "DivExp" || \
        node->node_type == "ModExp" || \
        node->node_type == "LOrExp" || \
        node->node_type == "LAndExp" || \
        node->node_type == "EqExp" || \
        node->node_type == "NEqExp" || \
        node->node_type == "LTExp" || \
        node->node_type == "GTExp" || \
        node->node_type == "LTEExp" || \
        node->node_type == "GTEExp")
        return true;
    return false;
}

bool ifUnary(Node* node) {
    if (node->node_type == "AddUnaryExp" || \
        node->node_type == "SubUnaryExp" || \
        node->node_type == "NotUnaryExp")
        return true;
    return false;
}

bool ifVarDef(Node* node) {
    if (node->node_type == "IntegerVarDef" || \
        node->node_type == "BracketVarDef")
        return true;
    return false;
}

bool ifBorC(Node* node) {
    if (node->node_type == "BreakStmt" || \
        node->node_type == "ContinueStmt")
        return true;
    return false;
}

/*------------------------------------------------------------------------*/

// binary exp
bool check_exp(Node* node) {
    if (node->is_terminal())
        throw("check_exp wrong: node is terminal");
    auto temp = static_cast<NonTerminalNode*>(node);
    VType left = check_type(temp->child_list[0]);
    VType right = check_type(temp->child_list[1]);
    if (left == "INT" && right == "INT")
        return true;
    else {
        std::cerr << "The type of the left end and the right end are different. \n";
        exit(1);
    }

    return false;
}

// IfElseStmt
bool check_if(Node* node) {
    auto temp = static_cast<NonTerminalNode*>(node);
    if (temp->child_list.size() == 0) {
        std::cerr << "the if is wrong.\n";
        exit(1);
    }

    auto if_exp = temp->child_list[0];
    if (check_type(if_exp) != "INT") {
        std::cerr << "the exp of if is wrong.\n";
        exit(1);
    }
    return true;
}

// WhileStmt
bool check_while(Node* node) {
    auto temp = static_cast<NonTerminalNode*>(node);
    if (temp->child_list.size() == 0) {
        std::cerr << "the while is wrong.\n";
        exit(1);
    }
    auto while_exp = temp->child_list[0];
    if (check_type(while_exp) != "INT") {
        std::cerr << "the exp of while is wrong.\n";
        exit(1);
    }
    return true;
}

// ReturnStmt
bool check_return(Node* node) {
    auto temp = static_cast<NonTerminalNode*>(node);
    auto reserve_ptr = static_cast<ReservedLiteral*>(temp->child_list[0]);
    if (reserve_ptr->node_type != "Reserved_Return") {
        std::cerr << "the reserve return is wrong.\n";
        exit(1);
    }

    // 检查类型为void
    if (temp->child_list.size() == 1 && now_funcType == "VOID")
        return true;
    // 检查类型为int
    else if (check_type(temp->child_list[1]) == "INT" && now_funcType == "INT")
        return true;
    std::cerr << "the return is wrong.\n";
    exit(1);
}

// BreakStmt or ContinueStmt
bool check_breakAndcontinue(Node* node) {
    if (!ifBorC(node)) {
        std::cerr << "the stmt is wrong.\n";
        exit(1);
    }

    if (!if_inloop) {
        std::cerr << "There is not in loop.\n";
        exit(1);
    }
    return true;
}

/*
    FuncCall
    1. 检查函数是否有过声明
    2. 检查函数的参数列表是否与表中一致，包括个数，类型（数组等）
*/
bool check_func(Node* node) {

    auto temp_node = static_cast<NonTerminalNode*>(node);
    auto id_ptr = static_cast<IdentLiteral*>(temp_node->child_list[0]);
    std::string id = id_ptr->value;
    if (find_func(id) == nullptr) {
        std::cerr << "the function has not been defined.\n";
        exit(1);
    }

    // 符号表中函数结点
    auto func_node = find_func(id);
    int def_size = func_node->FuncParams.size();
    int func_size = 0;

    if (temp_node->child_list.size() > 1) {
        auto param_node = static_cast<NonTerminalNode*>(temp_node->child_list[1]);
        func_size = param_node->child_list.size();
    }

    if (def_size != func_size) {
        std::cerr << "The num of params is wrong.\n";
        exit(1);
    }

    // TODO 检查各个参数， 注意数组类型
    for (int i = 0; i < func_size; i++) {
        auto param_node = static_cast<NonTerminalNode*>(temp_node->child_list[1]);
        VType tp = check_type(param_node->child_list[i]);

        if (func_node->FuncParams[i].type != tp) {
            std::cerr << "The type of param is wrong.\n";
            exit(1);
        }

        if (tp == "VOID") {
            std::cerr << "Wrong type: param can't be void.\n";
            exit(1);
        }

        if (tp == "INT")
            continue;

        if (tp == "ARRAY") {
            auto now_param = static_cast<NonTerminalNode*>(param_node->child_list[i]);
            auto id_ptr = static_cast<IdentLiteral*>(now_param->child_list[0]);
            std::string id = id_ptr->value;
            int useless_dim = 0;
            if (now_param->child_list.size() == 1)
                useless_dim = 0;
            if (now_param->child_list.size() == 2) {
                auto list_ptr = static_cast<NonTerminalNode*>(now_param->child_list[1]);
                useless_dim = list_ptr->child_list.size();
            }

            auto array_var = find_id(id);
            if (array_var == nullptr) {
                std::cerr << "something wrong about the array.\n";
                exit(1);
            }

            if (func_node->FuncParams[i].dim != (array_var->dim - useless_dim)) {
                std::cerr << "the dim is wrong.\n";
                exit(1);
            }

            int dim = func_node->FuncParams[i].dim;
            // 检查多维数组是否合规，如f(int a[][2]) int b[1][3]  f(b) x
            for (int k = 1; k < dim; k++) {
                if (array_var->size[k + useless_dim] != func_node->FuncParams[i].size[k])
                {
                    std::cerr << "The array is wrong.\n";
                    exit(1);
                }
            }
        }
    }
    return true;
}

// VarDecl
void push_newId(Node* node) {
    auto temp_node = static_cast<NonTerminalNode*>(node);
    int num = temp_node->child_list.size() - 1;
    for (int i = 1; i <= num; i++) {
        auto vardef = static_cast<NonTerminalNode*>(temp_node->child_list[i]);
        if (!ifVarDef(vardef)) {
            std::cerr << "Vardef is wrong.\n";
            exit(1);
        }

        auto id_ptr = static_cast<IdentLiteral*>(vardef->child_list[0]);
        std::string id = id_ptr->value;
        if (find_id_inScope(id)) {
            std::cerr << "The var " << id << " has been difined in this scope.\n";
            exit(1);
        }

        if (vardef->node_type == "IntegerVarDef") {
            if (vardef->child_list.size() > 1) {
                auto val_ptr = static_cast<NonTerminalNode*>(vardef->child_list[1]);
                if (check_type(val_ptr) != "INT") {
                    std::cerr << "The initial value of the var is not int.\n";
                    exit(1);
                }
            }
            auto new_idNode = new IdentNode();
            new_idNode->dim = 0;
            new_idNode->type = "INT";
            int top = IdentMap.size() - 1;
            IdentMap[top][id] = *new_idNode;
        }
        else {
            auto list_ptr = static_cast<NonTerminalNode*>(vardef->child_list[1]);
            auto new_idNode = new IdentNode();
            new_idNode->dim = list_ptr->child_list.size();
            for (int k = 0; k < new_idNode->dim; k++) {
                auto size_ptr = static_cast<IntegerLiteral*>(list_ptr->child_list[k]);
                new_idNode->size.push_back(size_ptr->value);
            }
            new_idNode->type = "ARRAY";
            int top = IdentMap.size() - 1;
            IdentMap[top][id] = *new_idNode;
        }
    }
}

// FuncDef 
void push_newFunc(Node* node) {
    auto temp_node = static_cast<NonTerminalNode*>(node);
    auto func_node = new FuncNode();
    auto type_ptr = static_cast<IdentTypeLiteral*>(temp_node->child_list[0]);
    auto id_ptr = static_cast<IdentLiteral*>(temp_node->child_list[1]);
    std::string id = id_ptr->value;
    if (find_func(id) != nullptr) {
        std::cerr << "The function has been defined.\n";
        exit(1);
    }

    VType tp = "ERROR";
    if (type_ptr->node_type == "IdentType_VOID")
        tp = "VOID";
    if (type_ptr->node_type == "IdentType_INT")
        tp = "INT";
    func_node->type = tp;
    now_funcType = tp;

    if (temp_node->child_list[2]->node_type == "Block") {
        FuncMap[id] = *func_node;
        return;
    }

    if (temp_node->child_list[2]->node_type == "FuncFParams") {
        int top = IdentMap.size() - 1;
        auto params = static_cast<NonTerminalNode*>(temp_node->child_list[2]);
        // 函数的形参个数
        int num = params->child_list.size(); 
        for (int i = 0; i < num; i++) {
            auto new_param = new IdentNode();
            auto now_param = static_cast<NonTerminalNode*>(params->child_list[i]);

            if (now_param->node_type == "IntegerFuncFParam") {
                auto id_ptr = static_cast<IdentLiteral*>(now_param->child_list[1]);
                std::string id = id_ptr->value;
                if (find_id_inScope(id)) {
                    std::cerr << "the ident of param has been defined.\n";
                    exit(1);
                }

                new_param->type = "INT";
                new_param->dim = 0;
                IdentMap[top][id] = *new_param;
            }

            if (now_param->node_type == "BracketFuncFParam") {
                auto id_ptr = static_cast<IdentLiteral*>(now_param->child_list[1]);
                std::string id = id_ptr->value;
                if (find_id_inScope(id)) {
                    std::cerr << "the ident of param has been defined.\n";
                    exit(1);
                }
                new_param->type = "ARRAY";
                // 因为是函数参数，数组的大小是未知的，所以以指针的形式存储
                new_param->size.push_back(0);

                // 函数形参中数组的ast结构是
                // TYPE - Ident - [ - Bracket - ]
                //                  - Integer - Integer - ...
                auto bra_ptr = static_cast<NonTerminalNode*>(now_param->child_list[2]);
                int dim = bra_ptr->child_list.size() + 1;
                new_param->dim = dim;
                for (int i = 0; i < dim - 1; i++) {
                    auto int_ptr = static_cast<IntegerLiteral*>(bra_ptr->child_list[i]);
                    int size = int_ptr->value;
                    new_param->size.push_back(size);
                }
                IdentMap[top][id] = *new_param;
            }
            func_node->FuncParams.push_back(*new_param);
        }
        FuncMap[id] = *func_node;
    }
    return;
}


/*
    需要检查的类型有：
    1. LVal INT ARRAY VOID
    2. Unary 一元表达式
    3. Binary 二元表达式
    4. integer
    5. FuncCall
*/
VType check_type(Node* node) {
    // Lval INT VOID ARRAY
    if (node->node_type == "LVal") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto id_ptr = static_cast<IdentLiteral*>(temp_node->child_list[0]);
        std::string id = id_ptr->value;
        auto find_ptr = find_id(id);
        if (find_ptr == nullptr) {
            std::cerr << "Undefined ident.\n";
            exit(1);
        }
        int max_dim = find_ptr->dim;

        if (temp_node->child_list.size() == 1 && max_dim == 0)
            return "INT";
        if (temp_node->child_list.size() == 1 && max_dim > 0)
            return "ARRAY";
        if (temp_node->child_list.size() > 1 && max_dim > 0) {
            auto bra_ptr = static_cast<NonTerminalNode*>(temp_node->child_list[1]);
            int now_dim = bra_ptr->child_list.size();
            for (int i = 0; i < now_dim; i++) {
                if (check_type(bra_ptr->child_list[i]) != "INT") {
                    std::cerr << "the index of array is not INT.\n";
                    exit(1);
                }
            }
            if (now_dim == max_dim)
                return "INT";
            else if (now_dim < max_dim)
                return "ARRAY";
            else {
                std::cerr << "the dim of the array is more than the defined.\n";
                exit(1);
            }
        }
        if (temp_node->child_list.size() > 1 && max_dim == 0) {
            std::cerr << "the var is int, not array.\n";
            exit(1);
        }
    }

    // Integer
    if (node->node_type == "IntegerLiteral")
        return "INT";

    // Binary
    if (ifBanary(node)) {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto left = temp_node->child_list[0];
        auto right = temp_node->child_list[1];
        VType l = check_type(left);
        VType r = check_type(right);

        if (l == "INT" && r == "INT")
            return "INT";
        else {
            std::cerr << "The Exp is wrong.\n";
            exit(1);
        }
    }

    // Unary
    if (ifUnary(node)) {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        VType v = check_type(temp_node->child_list[0]);
        if (v != "INT") {
            std::cerr << "The Unary is wrong.\n";
            exit(1);
        }

        else
            return "INT";
    }

    // FuncCall
    if (node->node_type == "FuncCall") {
        if (!check_func(node)) {
            std::cerr << "The Func is wrong.\n";
            exit(1);
        }

        auto temp_node = static_cast<NonTerminalNode*>(node);
        auto func_node = static_cast<IdentLiteral*>(temp_node->child_list[0]);
        std::string func_name = func_node->value;
        FuncNode* f = find_func(func_name);
        return f->type;
    }
}

bool recursive_check_tree(Node* node) {
    bool flag = true;
    if (node->is_terminal())
        return true;
    else {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        int size = temp_node->child_list.size();
        for (int i = 0; i < size; i++) {
            flag = (flag && check_tree(temp_node->child_list[i]));
        }
    }
    return flag;
}

bool check_tree(Node* node) {
    bool flag = true;

    if (node->node_type == "CompUnit") {
        push_domain();
        init_domain();
        flag = recursive_check_tree(node);
        pop_domain();
    }

    if (node->node_type == "VarDecl") {
        push_newId(node);
    }

    if (node->node_type == "FuncDef") {
        push_domain();
        if_infunc = true;
        push_newFunc(node);
        flag = recursive_check_tree(node);
        now_funcType = "ERROR";
        if_infunc = false;
        already_copy = false;
        pop_domain();
    }

    if (node->node_type == "Block") {
        push_domain();
        if (if_infunc && !already_copy) {
            copy_domain();
            already_copy = true;
        }
        flag = recursive_check_tree(node);
        pop_domain();
    }

    if (node->node_type == "AssignStmt") {
        auto temp_node = static_cast<NonTerminalNode*>(node);
        if (temp_node->child_list[0]->node_type != "LVal")
            flag = false;
        std::string l = check_type(temp_node->child_list[0]);
        std::string r = check_type(temp_node->child_list[1]);
        if (l != "INT" || r != "INT")
            flag = false;
    }

    if (node->node_type == "IfElseStmt") {
        if (check_if(node))
            flag = recursive_check_tree(node);
        else
            flag = false;
    }

    if (node->node_type == "WhileStmt") {
        if_inloop = true;
        if (check_while(node))
            flag = recursive_check_tree(node);
        else
            flag = false;
        if_inloop = false;
    }

    if (node->node_type == "BreakStmt" || node->node_type == "ContinueStmt") {
        if (if_inloop)
        {
            flag = check_breakAndcontinue(node);
        }
        else
            flag = false;
    }

    if (node->node_type == "ReturnStmt") {
        if (if_infunc)
            flag = check_return(node);
        else
            flag = false;
    }

    if (node->node_type == "FuncCall") {
        flag = check_func(node);
    }

    if (ifBanary(node)) {
        if (check_type(node) != "INT")
            flag = false;
    }

    if (node->node_type == "LVal") {
        if (check_type(node) == "ERROR" || check_type(node) == "VOID")
            flag = false;
    }

    return flag;
}