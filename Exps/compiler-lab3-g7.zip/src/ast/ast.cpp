#include "ast/ast.h"

#include <iostream>
#include <fmt/core.h>
#include <cassert>

void print_tree(Node* node, std::string prefix = "", std::string ident = "") {
    assert(node != nullptr);
    fmt::print(prefix);
    if (node->is_terminal()) {
        if (node->node_type == "IntegerLiteral") {
            IntegerLiteral* temp_node = static_cast<IntegerLiteral*>(node);
            fmt::print("Integer \033[33m\"{}\"\033[0m", temp_node->value);
        }
        else if (node->node_type == "IdentLiteral") {
            IdentLiteral* temp_node = static_cast<IdentLiteral*>(node);
            fmt::print("Ident \033[36m\"{}\"\033[0m", temp_node->value);
        }
        else if (node->node_type == "IdentType_INT") {
            fmt::print("IdentType \033[31m\"int\"\033[0m");
        }
        else if (node->node_type == "IdentType_VOID") {
            fmt::print("IdentType \033[31m\"void\"\033[0m");
        }
        else if (node->node_type == "Reserved_Break") {
            fmt::print("Reserved \033[32m\"break\"\033[0m");
        }
        else if (node->node_type == "Reserved_Continue") {
            fmt::print("Reserved \033[32m\"continue\"\033[0m");
        }
        else if (node->node_type == "Reserved_Return") {
            fmt::print("Reserved \033[32m\"return\"\033[0m");
        }
        fmt::print("\n");
    }
    else {
        NonTerminalNode* temp_node = static_cast<NonTerminalNode*>(node);
        fmt::print("{}\n", node->node_type);
        for (long unsigned int i = 0;i < temp_node->child_list.size();i++) {
            if (i != temp_node->child_list.size() - 1) {
                print_tree(temp_node->child_list[i], ident + "├── ", ident + "│   ");
            }
            else {
                print_tree(temp_node->child_list[i], ident + "└── ", ident + "    ");
            }
        }
    }
}
