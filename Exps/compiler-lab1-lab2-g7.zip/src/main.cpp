#include "ast/ast.h"
#include "ast/check.h"
#include "ir/ir_ctor.h"

#include <iostream>
#include <fmt/core.h>

extern int yyparse();
extern FILE* yyin;

Node* root;

int main(int argc, char** argv) {
    /* read input */
    yyin = fopen(argv[1], "r");
    if (yyin == NULL) {
        perror(argv[1]);
        return 1;
    }

    /* lexer and paser */
    yyparse();
    print_tree(root, "", "");
    fmt::print("\033[32m[PASSED] \033[0m| finish parsing.\n");

    /* semantic check */
    if (!check_tree(root)) {
        fmt::print("\033[31m[FAILED] \033[0m| semantic error.\n");
        exit(1);
    }
    else {
        fmt::print("\033[32m[PASSED] \033[0m| finish semantic checking.\n");
    }

    /* construct ir */
    

    return 0;
}
