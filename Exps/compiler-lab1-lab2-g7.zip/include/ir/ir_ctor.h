class SymbolTable {

};

void translate_expr();

void translate_stmt();