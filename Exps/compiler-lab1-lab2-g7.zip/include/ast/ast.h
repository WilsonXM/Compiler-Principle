#pragma once
#include <cstdint>
#include <type_traits>
#include <vector>
#include <string>

// enum NodeType {
// #define TreeNodeDefine(x) x,
// #include "../common/common.def"
// };

using NodeType = std::string;

struct Node {
    NodeType node_type;
    Node(NodeType type) : node_type(type) {}
    bool is(NodeType type) { return node_type == type; }
    virtual bool is_terminal() = 0;
};

struct NonTerminalNode : public Node {
    std::vector<Node*> child_list{};
    NonTerminalNode(NodeType type) : Node(type) {}
    void add_child_back(Node* child) { child_list.push_back(child); }
    void add_child_front(Node* child) { child_list.insert(child_list.begin(), child); }
    bool is_terminal() { return false; }
};

struct TerminalNode : public Node {
    TerminalNode(NodeType type) : Node(type) {}
    bool is_terminal() { return true; }
};

struct IntegerLiteral : public TerminalNode {
    int64_t value;
    IntegerLiteral(int64_t v) : TerminalNode("IntegerLiteral"), value(v) {}
};

struct IdentLiteral : public TerminalNode {
    std::string value;
    IdentLiteral(std::string v) : TerminalNode("IdentLiteral"), value(v) {}
};

struct IdentTypeLiteral : public TerminalNode {
    IdentTypeLiteral(NodeType type) : TerminalNode(type) {}
};

struct ReservedLiteral : public TerminalNode {
    ReservedLiteral(NodeType type) : TerminalNode(type) {}
};

/* tree-printing function */
void print_tree(Node* node, std::string prefix, std::string ident);