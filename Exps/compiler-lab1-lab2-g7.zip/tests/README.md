# 测试说明

这些测试主要来自[全国大学生计算机系统能力大赛](https://compiler.educg.net/#/)、[NJU编译原理](https://cs.nju.edu.cn/changxu/2_compiler/index.html)和[刘老师班](https://git.zju.edu.cn/compiler/sp24-starter)，我们对测试进行了适当的修改来适应本课程。
