cmake --build build
cd tests/ && python3 test.py ../build/compiler lab$1 && cd ..